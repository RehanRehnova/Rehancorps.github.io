# REHNOVA Vault v1.1.0

Free, local-first **password generator + credential vault** for Chromium browsers.

| Feature | Detail |
|--------|--------|
| Generate | CSPRNG passwords on any password field |
| Save / refill | Per-site credentials, confirm to save, fill bar on return |
| **AES master lock** | AES-256-GCM, PBKDF2-SHA256 (310k iters) |
| Export / import | JSON backup (encrypted when lock is on) |
| Network | **None** for vault data |

## Install (developer)

1. `chrome://extensions` → Developer mode  
2. **Load unpacked** → this `extension` folder  
3. Popup → **Enable AES lock** (recommended)

## Publish

See **[PUBLISH.md](./PUBLISH.md)** for Chrome Web Store + free GitHub zip steps.

```powershell
.\extension\pack.ps1
# → rehnova-vault-1.1.0.zip at repo root
```

## Privacy

See [privacy.html](./privacy.html). Host it on HTTPS before store submission.

## Stack

Manifest V3 · vanilla JS · Web Crypto · `chrome.storage.local` + `session` · no build tools · no backend.
